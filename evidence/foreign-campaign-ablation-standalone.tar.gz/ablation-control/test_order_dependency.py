"""Deliberately order-dependent synthetic negative control; not upstream code."""
STATE=[]
def test_01_produce():
    STATE.append('produced')
def test_02_consume():
    assert STATE == ['produced']
